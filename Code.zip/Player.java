/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: The class of the player
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
import java.math.*;
import java.lang.Byte;

public class Player implements Common
{
    private int id;
    static public double alpha=0.001;
    static public double lambda=0.5;
    private double currWValue;
    private double currBValue;
    private double reward;
    private double[] index;
    TextArea toWSaveGame=new TextArea();
    TextArea toBSaveGame=new TextArea();
    Model modelOfPlayer;
    static public String nextMoveSuggestionsForHuman ;//to hint gia tin epomeni kinisi

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
                /* constructor */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public Player(int ident,String theLogin)
    {
       id=ident;
       modelOfPlayer=new Model(id,theLogin);
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* get human player(white) moves from keyboard */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public final int[] humanWMoveFromKeyboard(Pawn[] whitePawns,Square[][] woutSquare)
    {
       int[] selMoveDesc=new int[2];
       byte[] bytes = new byte[4];
       //VisualBoardFrame.enableInputText();
       while(true)
       {
         if(Spiel.myVisualBoardFrame.visualBoard.inputFromTextField!="")
         {
            //epeksergasia kinisis
            if(Spiel.myVisualBoardFrame.visualBoard.inputFromTextField.length()!=4)
            {
               Spiel.myVisualBoardFrame.visualBoard.inputFromTextField="";
               System.out.println("Ksanapekse 1");
               continue;
            }
            else
            {
               bytes=Spiel.myVisualBoardFrame.visualBoard.inputFromTextField.getBytes();
               Byte b1=new Byte(bytes[0]);
               Byte b2=new Byte(bytes[1]);
               int temp1=b1.intValue()-48;
               int temp2=b2.intValue()-48;
               if((temp1>=DIMBOARD)||(temp1<0)||(temp2>=DIMBOARD)||(temp2<0))
               {
                  System.out.println("Ektos orion skakieras. Prospathise pali!!!");
                  Spiel.myVisualBoardFrame.visualBoard.inputFromTextField="";
                  System.out.println("Ksanapekse 2");
                  continue;
               }
               Square source=woutSquare[temp1][temp2]; //the source square
               //the second 2 bytes are the to square(the sink)
               Byte b3=new Byte(bytes[2]);
               Byte b4=new Byte(bytes[3]);
               int temp3=b3.intValue()-48;
               int temp4=b4.intValue()-48;
               if((temp3>=DIMBOARD)||(temp3<0)||(temp4>=DIMBOARD)||temp4<0)
               {
                  System.out.println("Ektos orion skakieras. Prospathise pali!!!");
                  Spiel.myVisualBoardFrame.visualBoard.inputFromTextField="";
                  System.out.println("Ksanapekse 3");
                  continue;
               }
               //System.out.println("From:\t"+temp1+""+temp2+"\tTo\t"+temp3+temp4);
               Square sink=woutSquare[temp3][temp4]; //to sink square
               //move whitePawns from source to sink
               boolean check=Spiel.myPosition.isFinal(Spiel.myPosition.whitePawns,Spiel.myPosition.blackPawns);
               if((checkHumanWhiteMove(whitePawns,source,sink,woutSquare))&&(!check))
               {
                   humanWhite(whitePawns,source,sink,woutSquare);
               }
               else
               {
                   System.out.println("Ksanapekse 4");
                   Spiel.myVisualBoardFrame.visualBoard.inputFromTextField="";
                   continue;
               }
              break;
            }
         } //if
       } //while
       Spiel.myVisualBoardFrame.visualBoard.inputFromTextField="";
       return selMoveDesc;
}
/******************************************************************************/
//Check the validity of the white human moves
public final boolean checkHumanWhiteMove(Pawn[] whitePawn,Square source,Square sink,Square[][] woutSquare)
{
 int j=-1;
  boolean goOn=false;
  for (int i=0;i<NUMOFPAWNS;i++)
  {
    if ((whitePawn[i].position.getXCoord()==source.getXCoord())&&(whitePawn[i].position.getYCoord()==source.getYCoord())&&(whitePawn[i].isAlive()))
    {
      j=i;
      goOn=true;
      break;
    }
    else
    {
      continue;
    }
  }//end of for
  if (goOn==false)
  {
//     System.out.println("prin to return false1");
     return false;
  }
  Square legSquare[]=new Square[2*DIMBASE];
  //get all legal moves for the whitePawn[j] ->epistrefei sosta apotelesmata
  legSquare=whitePawn[j].getLegitMovesForWhitePawn(woutSquare);
  int flag=1;
  for (int g=0;g<legSquare.length;g++)
  {
     if((!sink.isInWhiteBase())&&(sink.getXCoord()==legSquare[g].getXCoord())&&(sink.getYCoord()==legSquare[g].getYCoord()))
      flag=2;
  }
  if (flag==2) return true;
//  System.out.println("prin to return false2");
  return false;
}
/******************************************************************************/
// -eirini- //
/******************************************************************************/
//make the move
public final void humanWhite(Pawn[] whitePawn,Square source,Square sink,Square[][] woutSquare)
{
  int j=-1;
  double valueOfMovement = -1;//pote den tha einai toso
  for (int i=0;i<NUMOFPAWNS;i++)
  {
     if ((whitePawn[i].position.getXCoord()==source.getXCoord())&&(whitePawn[i].position.getYCoord()==source.getYCoord()))
        j=i;
  }
  Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
  helpSquare=Spiel.myPosition.getAllMovesForWhitePlayer(woutSquare); // get all legal moves for white
  double[] aux=Spiel.myPosition.getWValue(j,sink); //�� ���������� ���� ��� ����������
  valueOfMovement=aux[0];
  whitePawn[j].movePawn(source,sink); //the whitePawn[j] movement is valid
  Spiel.myVisualBoardFrame.visualBoard.moveVisualPawn(source.getXCoord(),source.getYCoord(),1,sink.getXCoord(),sink.getYCoord());
  modelOfPlayer.increaseNumOfMoves(); //enimerose to montelo tou paikti
//  System.out.println("\t=>\tEgine megale me value="+valueOfMovement);
  Spiel.myPosition.refreshPosition();
  createWSaveGame(source.xCoord+""+source.yCoord+"-->"+sink.xCoord+""+sink.yCoord+"-->"+  valueOfMovement+'\n');
  //enimerose to montelo tou paikti
  modelOfPlayer.updateValuesOfChoosenMoves(valueOfMovement);
}
/******************************************************************************/
  //not used, a human black player moves
  public final void humanBlack(Pawn[] blackPawn,Square source,Square sink){
    int j=-1;
    for (int i=0;i<NUMOFPAWNS;i++){
      if (blackPawn[i].position.equals(source)) j=i;
    }
    blackPawn[j].movePawn(source,sink);
    Spiel.myPosition.refreshPosition();
    createBSaveGame(source.xCoord+source.yCoord+"->"+sink.xCoord+sink.yCoord+'\t');
  }
/******************************************************************************/
// computer white plays
public final int[] pickWhiteMove(Pawn[] whitePawn,Square[][] woutSquare)
{
    int[] selMoveDesc=new int[2];
    Pawn[] whitPawn=whitePawn;
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare=Spiel.myPosition.getAllMovesForWhitePlayer(woutSquare); // get all legal moves for white
    selMoveDesc=whiteChooses(whitPawn,helpSquare);  //play one of them
    return selMoveDesc;
}
/******************************************************************************/
// computer plays for the white human
public final int[] pickComputersMoveForWhiteHuman(Pawn[] whitePawn,Square[][] woutSquare)
{
    int[] selMoveDesc=new int[2];
    Pawn[] whitPawn=whitePawn;
    Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
    helpSquare=Spiel.myPosition.getAllMovesForWhitePlayer(woutSquare); // get all legal moves for all pawns of the white player
    selMoveDesc=computerChoosesMoveForWhiteHuman(whitPawn,helpSquare);  //play one of them
    return selMoveDesc;
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
          /* computer black plays */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
public final int[] pickBlackMove(Pawn[] blackPawns,Square[][] boutSquare)
{
   int[] selMoveDesc=new int[2];
   Pawn[] blackPawn=blackPawns;
   Square[][] helpSquare=new Square[NUMOFPAWNS][2*DIMBASE];
   //get all legal moves for black player
   helpSquare=Spiel.myPosition.getAllMovesForBlackPlayer(boutSquare);
   //choose  to play one of them
  selMoveDesc=blackChooses(blackPawn,helpSquare);
  return selMoveDesc;
}
/******************************************************************************/
  //choose a legal move
  private final int[] whiteChooses(Pawn[] whitPawn,Square[][] helpSquare)
  {
    int xx=-1;int yy=-1;
    Pawn[] whitePawn=whitPawn;
    double maxValue=-1000;
    double value;  // the value of the position that occurs after making a move
    boolean bestMove; //if true-> exploit, else ->explore
    Vector possiblePawns=new Vector();
    Vector possibleSquares=new Vector();
    java.util.Date helpDate=new Date();
    Random eSoftDecision=new Random(helpDate.getTime());
    double eSoft=eSoftDecision.nextDouble();
    bestMove=(eSoft<0.9)?true:false; //if eSoft is less than 0.9 then we exploit
    Random exploreWDecision=new Random(helpDate.getTime()+1230000);
    int moveCounter=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      for (int j=0;j<2*DIMBASE;j++){
        if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0){
          double[] aux=Spiel.myPosition.getWValue(i,helpSquare[i][j]); //get the value of the occuring position
          moveCounter++;
          possiblePawns.addElement(new Integer(i));
          possibleSquares.addElement(helpSquare[i][j]);
          value=aux[0];
          if (value>maxValue)
          { //if it is the biggest value, keep it
            maxValue=value;
            xx=i;
            yy=j;
          }

        }
      }
    }
    if (bestMove)
    {  //exploit
      int[] selMoveDesc=new int[2];
      createWSaveGame(""+whitePawn[xx].position.xCoord+Spiel.whitePawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"<"+maxValue+">");
//      System.out.println("move"+whitePawn[xx].position.xCoord+Spiel.whitePawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"<"+maxValue+">");
      selMoveDesc[0]=whitePawn[xx].position.square2Tag();
      selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
      // move the pawn
      whitePawn[xx].movePawn(whitePawn[xx].position,helpSquare[xx][yy]);
      // check for dead pawns
      Spiel.myPosition.refreshPosition();
      Spiel.myPosition.setCurrentWValue(maxValue);
      //transform pawns to binary array for the neural net
      Spiel.whiteNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
      // get the appropriate reward
      reward=Spiel.myPosition.getReward(true);
      //System.out.println("white reward= "+reward);

      boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
      // update the neural net
      Spiel.whiteNeural.singleStep(reward,setValue);
//      System.out.println("white Neural call with: reward= "+reward+" and setValue= "+setValue);
//      saveWGame(); //if uncommented then we also record the moves
      return selMoveDesc;
    }
    else {   //explore
      Spiel.whiteNeural.clearEligTrace(); //clear eligibility traces
      double explore=exploreWDecision.nextDouble();
      int target=(int)(explore*moveCounter);
      int chosenPawn=((Integer) possiblePawns.elementAt(target)).intValue();
      Square chosenSquare=(Square)possibleSquares.elementAt(target);
      double[] aux=Spiel.myPosition.getWValue(chosenPawn,chosenSquare);
      createWSaveGame(""+whitePawn[chosenPawn].position.xCoord+whitePawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+chosenSquare.yCoord+"<"+maxValue+">");
//      System.out.println("move"+whitePawn[chosenPawn].position.xCoord+whitePawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+chosenSquare.yCoord+"<"+maxValue+">");
//      createWhiteHumanSaveGame(""+whitePawn[chosenPawn].position.xCoord+whitePawn[chosenPawn].position.yCoord+"->"+chosenSquare.xCoord+chosenSquare.yCoord+"<"+maxValue+">");
      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=whitePawn[chosenPawn].position.square2Tag();
      selMoveDesc[1]=chosenSquare.square2Tag();
      // move pawn
      whitePawn[chosenPawn].movePawn(whitePawn[chosenPawn].position,chosenSquare);
      // check for dead
      Spiel.myPosition.refreshPosition();
      Spiel.whiteNeural.setOldOutputNode(aux[0]);
  //    saveWGame(); //uncomment to save the moves
      return selMoveDesc;
    }
  }

/*
Computer chooses a move for the white player
PROSOXH!!!!   only exploit no explore  !!!!
*/
public final int[] computerChoosesMoveForWhiteHuman(Pawn[] whitPawn,Square[][] helpSquare)
{
  int xx=-1;
  int yy=-1;
  int tt=-1;
  int gg=-1;
  Pawn[] whitePawn=whitPawn;
  double maxValue=-1000;
  double minValue=1000;
  double value=0;//eirini: the value of the position that occurs after making a move
  Vector possiblePawns=new Vector();
  Vector possibleSquares=new Vector();
  int moveCounter=0;
  boolean flag=false;
  Vector movesValues=new Vector();//ena vector me ta values ton moves
  Vector basesSquaresForSuggestion = new Vector();
  String tmp="";
  nextMoveSuggestionsForHuman="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n";
  for (int i=0;i<NUMOFPAWNS;i++)
  {
    for (int j=0;j<2*DIMBASE;j++)
    {
      if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0)
      {
        //get the value of the occuring position
        double[] aux=Spiel.myPosition.getWValue(i,helpSquare[i][j]);
        possiblePawns.addElement(new Integer(i));
        possibleSquares.addElement(helpSquare[i][j]);
        value=aux[0];
        //keep all the moves values
        movesValues.addElement(new Double(value));
        //find the bigest one
        if (value>maxValue)
        {
          maxValue=value;
          xx=i;
          yy=j;
        }
        if (value<minValue)
        {
          minValue=value;
          tt=i;
          gg=j;
        }
        if(whitePawn[i].position.isInWhiteBase())
        {
           if((basesSquaresForSuggestion==null)||(basesSquaresForSuggestion.indexOf(new Integer(helpSquare[i][j].square2Tag()))==-1))
           {
              if((helpSquare[i][j].getXCoord()+helpSquare[i][j].getYCoord())!=0)//gia logous asfaleias mi mou deiksei pote kinisi to 00
              {
                  basesSquaresForSuggestion.addElement(new Integer(helpSquare[i][j].square2Tag()));
                  tmp=""+(moveCounter+1)+"\t\t"+whitePawn[i].position.getXCoord()+""+whitePawn[i].position.getYCoord()+"\t\t"+helpSquare[i][j].getXCoord()+""+helpSquare[i][j].getYCoord()+"\t\t"+value+'\n';
                  nextMoveSuggestionsForHuman+=tmp;
                  moveCounter++;
              }
           }
        }
        else
        {
            if((helpSquare[i][j].getXCoord()+helpSquare[i][j].getYCoord())!=0)
            {
                tmp=""+(moveCounter+1)+"\t\t"+whitePawn[i].position.getXCoord()+""+whitePawn[i].position.getYCoord()+"\t\t"+helpSquare[i][j].getXCoord()+""+helpSquare[i][j].getYCoord()+"\t\t"+value+'\n';
                nextMoveSuggestionsForHuman+=tmp;
                moveCounter++;
            }
        }
      }//if
    }
    }
  int[] selMoveDesc=new int[2];
  //createWSaveGame(""+whitePawn[xx].position.xCoord+Spiel.whitePawn[xx].position.yCoord+"->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"<"+maxValue+">");
  selMoveDesc[0]=whitePawn[xx].position.square2Tag();
  selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
//
    int[] deadWhite=new int[NUMOFPAWNS];
    int[] deadBlack=new int[NUMOFPAWNS];
    Pawn[] cloneWhite=new Pawn[NUMOFPAWNS];
    Pawn[] cloneBlack=new Pawn[NUMOFPAWNS];
    Square dest=(Square)helpSquare[xx][yy].clone();
    //clone the board
    Square[][] cloneSquare=new Square[DIMBOARD][DIMBOARD];
    //clone the pawns
    for(int i=0;i<NUMOFPAWNS;i++)
    {
       cloneWhite[i]=(Pawn)Spiel.whitePawn[i].clone();
       cloneWhite[i].position=(Square)Spiel.whitePawn[i].position.clone();
       cloneBlack[i]=(Pawn)Spiel.blackPawn[i].clone();
       cloneBlack[i].position=(Square)Spiel.blackPawn[i].position.clone();
    }
    for(int i=0;i<DIMBOARD;i++)
    {
       for(int j=0;j<DIMBOARD;j++)
       {
         cloneSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
       }
    }
    // move the pawn
    cloneWhite[xx].movePawn(cloneWhite[xx].position,cloneSquare[dest.xCoord][dest.yCoord]);
    // check for dead pawns
    for(int i=0;i<NUMOFPAWNS;i++)
    {
       if((cloneBlack[i].isAlive())&&(cloneBlack[i].isBlackPawnMovable(cloneSquare)==false))
       {
         deadBlack[i]=1;
       }
      if ((cloneWhite[i].isAlive())&&(cloneWhite[i].isWhitePawnMovable(cloneSquare)==false)){
        deadWhite[i]=1;
      }
    }
    //kill dead pawns
    for (int i=0;i<NUMOFPAWNS;i++)
    {
      if (deadBlack[i]==1)
      {
        cloneBlack[i].killPawn();
      }
      if (deadWhite[i]==1)
      {
        cloneWhite[i].killPawn();
      }
    }
    Position clonePosition = new Position(cloneWhite,cloneBlack);
    clonePosition.setCurrentWValue(maxValue);
    Spiel.whiteNeural.pawnsToInput(cloneWhite,cloneBlack);
    reward=clonePosition.getReward(true);
    boolean setValue=clonePosition.isFinal(cloneWhite,cloneBlack);
    Spiel.whiteNeural.singleStep(reward,setValue);
    /*eirini
// move the pawn
whitePawn[xx].movePawn(whitePawn[xx].position,helpSquare[xx][yy]);
// check for dead pawns
Spiel.myPosition.refreshPosition();
Spiel.myPosition.setCurrentWValue(maxValue);
*//*
  //transform pawns to binary array for the neural net
  Spiel.whiteNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
  //get the appropriate reward
  reward=Spiel.myPosition.getReward(true);
  System.out.println("for white human reward= "+reward);
  boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
  //update the neural net
  Spiel.whiteNeural.singleStep(reward,setValue);*/
//  System.out.println("for the suggested move reward="+reward+"and setValue="+setValue);
  //saveWGame(); //if uncommented then we also record the moves
  modelOfPlayer.updateNeuralNetBestSuggestionsForPlayer(maxValue);
  modelOfPlayer.updateNeuralNetWorstSuggestionsForPlayer(minValue);

  String tmp2="Best exploit_move:\n"+Spiel.whitePawn[xx].position.xCoord+Spiel.whitePawn[xx].position.yCoord+"\t--->\t"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"\twith value:\t\t<"+maxValue+">\n";
  tmp2+="Worst exploit_move:\n"+Spiel.whitePawn[tt].position.xCoord+Spiel.whitePawn[tt].position.yCoord+"\t--->\t"+helpSquare[tt][gg].xCoord+helpSquare[tt][gg].yCoord+"\twith value:\t\t<"+minValue+">\n";
  nextMoveSuggestionsForHuman+=tmp2;
  return selMoveDesc;
}
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
     /* choose a legal move for the black */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
private final int[] blackChooses(Pawn[] blacPawn,Square[][] helpSquare)
{
   int xx=-1;int yy=-1;
   Pawn[] blackPawn=blacPawn;
   double value=0;
   double maxValue=-1000;
   boolean bestMove;
   Vector possiblePawns=new Vector();
   Vector possibleSquares=new Vector();

   java.util.Date helpDate=new Date(); //to get a random double value
   Random eSoftDecision=new Random(helpDate.getTime()+2500321);
   double eSoft=eSoftDecision.nextDouble();
   bestMove=(eSoft<0.9)?true:false; //90%exploitation-10%exploration
   Random exploreBDecision=new Random(helpDate.getTime()+4000000);

   index=Spiel.myPosition.getCurrentBInd();
   int moveCounter=0;
   for (int i=0;i<NUMOFPAWNS;i++)
   {
     for (int j=0;j<2*DIMBASE;j++)
     {
       if ((helpSquare[i][j].xCoord+helpSquare[i][j].yCoord)!=0)
       {
          double[] aux=Spiel.myPosition.getBValue(i,helpSquare[i][j]);
          //System.out.println("aux[0]= "+aux[0]);
          moveCounter++;
          possiblePawns.addElement(new Integer(i));
          possibleSquares.addElement(helpSquare[i][j]);
          value=aux[0];
          if (value>maxValue)
          {
             maxValue=value;
             xx=i;
             yy=j;
          }
//          System.out.println(""+blackPawn[i].position.xCoord+blackPawn[i].position.yCoord+"-->"+helpSquare[i][j].xCoord+helpSquare[i][j].yCoord+"-->"+aux[0]);
       }
     }
   }
//   System.out.println(""+blackPawn[xx].position.xCoord+blackPawn[xx].position.yCoord+"-->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"-->"+maxValue);
    if (bestMove)
    {
      createBSaveGame(""+blackPawn[xx].position.xCoord+Spiel.blackPawn[xx].position.yCoord+"-->"+helpSquare[xx][yy].xCoord+helpSquare[xx][yy].yCoord+"-->"+maxValue);
      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[xx].position.square2Tag();
      selMoveDesc[1]=helpSquare[xx][yy].square2Tag();
      //afora to visual meros
      Spiel.myVisualBoardFrame.visualBoard.moveVisualPawn(blackPawn[xx].position.getXCoord(),blackPawn[xx].position.getYCoord(),0,helpSquare[xx][yy].getXCoord(),helpSquare[xx][yy].getYCoord());

      blackPawn[xx].movePawn(blackPawn[xx].position,helpSquare[xx][yy]);
      //refresh the board after the move
      Spiel.myPosition.refreshPosition();
      //se the positon bvalue to the maxValue
      Spiel.myPosition.setCurrentBValue(maxValue);
      //saveBGame(); //if uncomment it saves the game moves
      Spiel.blackNeural.pawnsToInput(Spiel.whitePawn,Spiel.blackPawn);
      reward=Spiel.myPosition.getReward(false);

      boolean setValue=Spiel.myPosition.isFinal(Spiel.whitePawn,Spiel.blackPawn);
   //   System.out.println("black reward= "+reward);
      Spiel.blackNeural.singleStep(reward,setValue);
      return selMoveDesc;
    }
    else
    {
      Spiel.blackNeural.clearEligTrace();
      double explore=exploreBDecision.nextDouble();
      int target=(int)(explore*moveCounter);
      int chosenPawn=((Integer) possiblePawns.elementAt(target)).intValue();
      Square chosenSquare=(Square)possibleSquares.elementAt(target);
      double[] aux=Spiel.myPosition.getBValue(chosenPawn,chosenSquare);
      createBSaveGame(""+blackPawn[chosenPawn].position.xCoord+blackPawn[chosenPawn].position.yCoord+"-->"+chosenSquare.xCoord+chosenSquare.yCoord+"-->"+maxValue);
//      System.out.println(""+blackPawn[chosenPawn].position.xCoord+blackPawn[chosenPawn].position.yCoord+"-->"+chosenSquare.xCoord+chosenSquare.yCoord+"-->"+maxValue);

      int[] selMoveDesc=new int[2];
      selMoveDesc[0]=blackPawn[chosenPawn].position.square2Tag();
      selMoveDesc[1]=chosenSquare.square2Tag();
      Spiel.myVisualBoardFrame.visualBoard.moveVisualPawn(blackPawn[chosenPawn].position.getXCoord(),blackPawn[chosenPawn].position.getYCoord(),0,chosenSquare.getXCoord(),chosenSquare.getYCoord());
      blackPawn[chosenPawn].movePawn(blackPawn[chosenPawn].position,chosenSquare);
      Spiel.myPosition.refreshPosition();
      Spiel.blackNeural.setOldOutputNode(aux[0]);
      //saveBGame();
      return selMoveDesc;
    }
  }
/******************************************************************************/
  public final void createWSaveGame(String s)
    {
        toWSaveGame.append(s);
        toWSaveGame.append("\n");

    }
/******************************************************************************/

     public final void saveWGame()
    {
       history savedWGame=new history();
       savedWGame.writeToFile(toWSaveGame.getText(),"aspra" );
    }
/******************************************************************************/
    public final void createBSaveGame(String s)
    {
        toBSaveGame.append(s);
        toBSaveGame.append("\n");

    }
/******************************************************************************/
     public final void saveBGame()
    {
       history savedBGame=new history();
       savedBGame.writeToFile(toBSaveGame.getText(),"mavra" );
    }
}//end of file