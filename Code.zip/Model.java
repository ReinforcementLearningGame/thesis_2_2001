/***************
  Created by:  Eirini Ntoutsi
  Operation: Implements the model of the player.
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
import java.lang.Math.*;

public class Model implements Common
{
   private int id;
   private String login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia

   private Vector historyOfAverageValuesPerMovePerGame;//mesos oros tis aksias ton kiniseon tou paikth gia kathe paixnidi
   private Vector valuesOfChoosenMoves; //ta values ton kiniseon pou epilegei o paiktis sto trexon paixnidi
   private Vector meanSquareDistanceFromNeuralNetBestSuggestions;
   private Vector meanSquareDistanceFromNeuralNetWorstSuggestions;
   private Vector neuralNetBestSuggestionsForPlayer;//dianysma me tis beltistes kiniseis pou  tou proteinei o ypologistis
   private Vector neuralNetWorstSuggestionsForPlayer;//dianysma me tis xeiroteres kiniseis pou  tou proteinei o ypologistis
   private Vector historyOfMovesPerGame; //poses kiniseis exei kanei se kathe paixnidi
   private Vector historyOfGamesResults;//an exei kerdisei i oxi se kathe paixnidi
//   private int pointsOfMaxDeclination; //se posa simeia i apoklisi tou apo ton ypologisti kseperna ena orio (den ksero akomi)

   //gia ton kathorismo tou montelou tou paikti
   private static double BEGINNER_PERCENT=0.4;
   private static double ADVANCED_PERCENT=0.8;

   public Model(int who,String theLogin)
   {
      id=who;
      login=theLogin;
      historyOfAverageValuesPerMovePerGame=new Vector();
      valuesOfChoosenMoves=new Vector();
      meanSquareDistanceFromNeuralNetBestSuggestions=new Vector();
      meanSquareDistanceFromNeuralNetWorstSuggestions=new Vector();
      neuralNetBestSuggestionsForPlayer=new Vector();
      neuralNetWorstSuggestionsForPlayer=new Vector();
      historyOfMovesPerGame=new Vector();
      historyOfGamesResults=new Vector();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getPlayerID()
   {
      return id;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfMovesPerGame(double x)
   {
      historyOfMovesPerGame.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfGamesResults(int s)
   {
   //if s=1=>gain, else if s=0=>lose
      historyOfGamesResults.addElement(new Integer(s));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfWinGames()
   {
      return numOfWinGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfWinGames()
   {
      numOfWinGames++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfLostGames()
   {
      return numOfLostGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfLostGames()
   {
      numOfLostGames++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMovesForGainedGames()
   {
      return numOfMovesForGainedGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMovesForLosedGames()
   {
      return numOfMovesForLosedGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfWinMoves(int what1 )
   {
      numOfMovesForGainedGames+=what1;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfLostMoves(int what2)
   {
      numOfMovesForLosedGames+=what2;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMoves()
   {
      return (numOfMovesForGainedGames+numOfMovesForLosedGames);
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfMoves()
   {
      numOfMoves++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void addValuesOfChoosenMovesForCurrentGame(Double valueOfMovement)
   {
     valuesOfChoosenMoves.addElement(valueOfMovement);
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNumOfPlayedGames()
   {
      return historyOfAverageValuesPerMovePerGame.size();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getHistoryOfAverageValuesPerMovePerGame()
   {
      Vector  result=new Vector();
      result=historyOfAverageValuesPerMovePerGame;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getMeanSquareDistanceFromNeuralNetBestSuggestions()
   {
      Vector  result=new Vector();
      result=meanSquareDistanceFromNeuralNetBestSuggestions;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getMeanSquareDistanceFromNeuralNetWorstSuggestions()
   {
      Vector  result=new Vector();
      result=meanSquareDistanceFromNeuralNetWorstSuggestions;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfAverageValuesPerMovePerGame(double res)
   {
      historyOfAverageValuesPerMovePerGame.addElement(new Double(res));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfAverageValuesPerMovePerGame()
   {
      for (int k=0;k<historyOfAverageValuesPerMovePerGame.size();k++)
         System.out.println("display historyOfAverageValuesPerGame: Game "+k+" = "+historyOfAverageValuesPerMovePerGame.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayValuesOfChoosenMoves()
   {
      for (int k=0;k<valuesOfChoosenMoves.size();k++)
         System.out.println("display valuesOfChoosenMoves: Game "+k+" = "+valuesOfChoosenMoves.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfMovesPerGame()
   {
      for (int k=0;k<historyOfMovesPerGame.size();k++)
         System.out.println("display historyOfMovesPerGame: Game "+k+" = "+historyOfMovesPerGame.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfGamesResults()
   {
      for (int k=0;k<historyOfGamesResults.size();k++)
         System.out.println("display historyOfGamesResults: Game "+k+" = "+historyOfGamesResults.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateValuesOfChoosenMoves(double x)
   {
       valuesOfChoosenMoves.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getSizeOfValuesOfChoosenMoves()
   {
       return valuesOfChoosenMoves.size();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateNeuralNetBestSuggestionsForPlayer(double x)
   {
      neuralNetBestSuggestionsForPlayer.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getNeuralNetBestSuggestion()
   {
      Vector  result=neuralNetBestSuggestionsForPlayer;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNeuralNetBestSuggestion(int k)
   {
       double tmp = ((Double)neuralNetBestSuggestionsForPlayer.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNeuralNetWorstSuggestion(int k)
   {
       double tmp = ((Double)neuralNetWorstSuggestionsForPlayer.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getValueOfChoosenMoves(int k)
   {
       double tmp = ((Double)valuesOfChoosenMoves.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateNeuralNetWorstSuggestionsForPlayer(double x)
   {
       neuralNetWorstSuggestionsForPlayer.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateMeanSquareDistanceFromNeuralNetBestSuggestions(double z)
   {       meanSquareDistanceFromNeuralNetBestSuggestions.addElement(new Double(z));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateMeanSquareDistanceFromNeuralNetWorstSuggestions(double v)
   {
      meanSquareDistanceFromNeuralNetWorstSuggestions.addElement(new Double(v));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayMeanSquareDistanceFromNeuralNetBestSuggestions()
   {
      for (int k=0;k<meanSquareDistanceFromNeuralNetBestSuggestions.size();k++)
         System.out.println("display meanSquareDistanceFromNeuralNetBestSuggestions: Game "+k+" = "+meanSquareDistanceFromNeuralNetBestSuggestions.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayMeanSquareDistanceFromNeuralNetWorstSuggestions()
   {
      for (int k=0;k<meanSquareDistanceFromNeuralNetWorstSuggestions.size();k++)
         System.out.println("display meanSquareDistanceFromNeuralNetWorstSuggestions: Game "+k+" = "+meanSquareDistanceFromNeuralNetWorstSuggestions.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getNeuralNetWorstSuggestion()
   {
      Vector  result=neuralNetWorstSuggestionsForPlayer;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getValueOfChoosenMoves()
   {
      Vector  result=valuesOfChoosenMoves;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getHistoryOfGameResults()
   {
      Vector  result=historyOfGamesResults;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getModel()
   {
      if(numOfWinGames+numOfLostGames<4)
         return UNKNOWN;
      float percent =numOfWinGames/(numOfWinGames+numOfLostGames);
      if (percent<=BEGINNER_PERCENT)
         return BEGINNER;
      if (percent>=ADVANCED_PERCENT)
         return EXPERT;
      return ADVANCED;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final String getLogin()
   {
      return login;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void storeModel()
   {
          try
          {
            ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(login+"_Model_{"+DIMBOARD+""+DIMBASE+""+NUMOFPAWNS+"}.txt"));
            out.writeObject(new Integer(numOfWinGames));
            out.writeObject(new Integer(numOfLostGames));
            out.writeObject(new Integer(numOfMoves));
            out.writeObject(new Integer(numOfMovesForGainedGames));
            out.writeObject(new Integer(numOfMovesForLosedGames));
            out.writeObject(historyOfAverageValuesPerMovePerGame);
            out.writeObject(historyOfMovesPerGame);
            out.writeObject(historyOfGamesResults);
            out.writeObject(meanSquareDistanceFromNeuralNetBestSuggestions);
            out.writeObject(meanSquareDistanceFromNeuralNetWorstSuggestions);
            out.close();
          }
          catch(Exception e){System.out.println("Error in writing to  file "+login+"_model.txt."); e.printStackTrace(); }
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final boolean loadModel()
   {
      try
      {
          ObjectInputStream in =new ObjectInputStream(new FileInputStream(login+"_Model_{"+DIMBOARD+""+DIMBASE+""+NUMOFPAWNS+"}.txt"));
          numOfWinGames=((Integer)in.readObject()).intValue();
          numOfLostGames=((Integer)in.readObject()).intValue();
          numOfMoves=((Integer)in.readObject()).intValue();
          numOfMovesForGainedGames=((Integer)in.readObject()).intValue();
          numOfMovesForLosedGames=((Integer)in.readObject()).intValue();
          historyOfAverageValuesPerMovePerGame=(Vector) in.readObject();
          historyOfMovesPerGame=(Vector) in.readObject();
          historyOfGamesResults=(Vector) in.readObject();
          meanSquareDistanceFromNeuralNetBestSuggestions=(Vector) in.readObject();
          meanSquareDistanceFromNeuralNetWorstSuggestions=(Vector) in.readObject();
          in.close();
          return true;
      }
      catch(IOException e){
          return false;
      }
      catch(ClassNotFoundException e){
          System.out.println(e.toString());
          return false;
      }

   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void storeDataForWeka(int numOfMovesForThisGame,
          double averageValueOfChoosenMovesForThisGame,
          double meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame,
          double meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame,
          String theLogin,
          int result)
   {
      history wekaHistory=new history();
      TextArea wekaData=new TextArea();
      wekaData.append(""+DIMBOARD+",");
      wekaData.append(""+DIMBASE+",");
      wekaData.append(""+NUMOFPAWNS+",");
      wekaData.append(""+numOfMovesForThisGame+",");
      wekaData.append(""+averageValueOfChoosenMovesForThisGame+",");
      wekaData.append(""+meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame+",");
      wekaData.append(""+meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame+",");
      wekaData.append(""+theLogin+",");
      wekaData.append(""+result+"\n");
      wekaHistory.appendFile(wekaData.getText(),"WEKA" );
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
}
//this is the end