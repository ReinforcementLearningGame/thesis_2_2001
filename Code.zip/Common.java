/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: Keeps some standard values used throughout the program
*******/
interface Common
{
   static final int DIMBOARD=8; //board size
   static final int DIMBASE=2; //base size
   static final int NUMOFPAWNS=10; //easy to understand

   //Possible models of players: begginer,advanced,expert,unknown
   static final int BEGINNER=1; //Beginner
   static final int ADVANCED=2; //Advanced
   static final int EXPERT=3; //Expert
   static final int UNKNOWN=0; //Unknown
}
//this is the end