/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: Creates the neural net, updates weights ...
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
public class NeuralNet implements Common
{
   int inputNodes,hiddenNodes,outputNodes;
   double ALPHA,BETA,GAMMA, LAMBDA; //constants for learning procedure
   double BIAS=0.5;//bias that each neuron has (input node 0),strength of the bias (constant input) contribution

   double[] inputNode;// array of input nodes  (1st layer)
   double[] hiddenNode;// array of hidden nodes (2nd layer)
   double[] outputNode;// array of output nodes (3rd layer)
   double[] oldOutputNode;// array used for updating weights

   double[] error;// error for each node
   double[] reward=new double[1];// the reward received for each decision

   double[][] v;// array of weights between layers 1->2
   double[][] w;// array of weights between layers 2->3
   double[][][] ev;// hidden trace
   double[][] ew;// output trace
   int owner;// which player plays??

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******
    /* the constructor */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public NeuralNet(int which,int input, int hidden, int output, double gamma, double lambda)
   {
      //the id of the player who owns the neural
      owner=which;
      //number of inputs=2*(DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5)=122
      inputNodes=input;
      //number of hidden
      hiddenNodes=hidden;
      //number of output=1
      outputNodes=output;
      GAMMA=gamma; //discount-rate parameter
      LAMBDA=lambda; //trace decay parameter
      ALPHA=1.0/inputNodes; //1-st layer learning rate
      BETA=1.0/hiddenNodes; //2-nd layer learning rate

      inputNode=new double[inputNodes+1]; //array of input nodes//123 elements
      hiddenNode=new double[hiddenNodes+1]; //array of hidden nodes //62 elements
      outputNode=new double[outputNodes]; //array of output nodes //1 element
      oldOutputNode=new double[outputNodes]; //array used for updating weights

      error=new double[outputNodes]; //TD error pou afora to output node

      //weights from input to hidden layer
      v=new double[inputNodes+1][hiddenNodes+1];
      //weights from hidden to output layer
      w=new double[hiddenNodes+1][outputNodes];
      //hidden trace
      ev=new double[inputNodes+1][hiddenNodes+1][outputNodes];
      //output trace
      ew=new double[hiddenNodes+1][outputNodes];
      initNetwork(); //initializes the network data structures
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    /* Initialize weights and biases */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void initNetwork()
   {
      int s,j,k,i;
      //this.initWeights();// used only for the first execution, just to randomize the weights
      this.loadWeights(); // used for the next executions, loads the stored weights
      inputNode[inputNodes]=BIAS; // last input node is set to BIAS
      hiddenNode[hiddenNodes]=BIAS; // last hidden node is set to BIAS

      for(j=0;j<=hiddenNodes;j++)
      {
         for(k=0;k<outputNodes;k++)
         {
            ew[j][k]=0.0;
            oldOutputNode[k]=0.0;
         }
         for(i=0;i<=inputNodes;i++)
         {
            for(k=0;k<outputNodes;k++)
            {
               ev[i][j][k]=0.0;
            }
         }
      }
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Initializes the weights v[][] and w[][] with a small random number */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void initWeights()
   {
      int j,k,i;
      java.util.Date helpDate=new Date();  // variable used for randomization
      Random initWeight=new Random(helpDate.getTime());
      for(j=0;j<=hiddenNodes;j++)
      {
         for (k=0;k<outputNodes;k++)
         {
            w[j][k]= initWeight.nextDouble()-0.5;
         }
         for(i=0;i<=inputNodes;i++)
         {
            v[i][j]= initWeight.nextDouble()-0.5;
         }
      }
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    /* Loads the weights v[][] and w[][] */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void loadWeights()
   {
      try
      {
          ObjectInputStream in =new ObjectInputStream(new FileInputStream((this.owner==1)? "whWWeights": "blWWeights"));
          w=(double[][]) in.readObject();

          in =new ObjectInputStream(new FileInputStream((this.owner==1)? "whVWeights": "blVWeights"));
          v=(double[][]) in.readObject();
      }
      catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
      /* the class name tells the story */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void storeWeights()
   {
      try
      {
          ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream((this.owner==1)? "whWWeights":"blWWeights"));
          out.writeObject(w);
          out.close();
          out=new ObjectOutputStream(new FileOutputStream((this.owner==1)? "whVWeights":"blVWeights"));
          out.writeObject(v);
          out.close();
      }
      catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    /* the forward propagation: computes
       hidden layer and output predictions  */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double[] Response()
   {
      int i,j,k;
      hiddenNode[hiddenNodes]=BIAS;
      inputNode[inputNodes]=BIAS;

      //calculate the hidden nodes' value using the sigmoid function
      for(j=0;j<hiddenNodes;j++)
      {
         hiddenNode[j]=0.0;
         for(i=0;i<=inputNodes;i++)
         {
            hiddenNode[j]+=inputNode[i]*v[i][j];
         }
         hiddenNode[j]=1.0/(1.0+ java.lang.Math.exp(-hiddenNode[j])); /* asymmetric sigmoid */
      }

      //calculate the output nodes' value using the sigmoid function
      for(k=0;k<outputNodes;k++)
      {
         outputNode[k]=0.0;
         for(j=0;j<=hiddenNodes;j++)
         {
            outputNode[k]+=hiddenNode[j]*w[j][k];
         }
         outputNode[k]=1.0/(1.0+java.lang.Math.exp(-outputNode[k]));
      }
      return outputNode;
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******
   /* backpropagates the TD errors and updates the
      weights according to the error observed */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void TDlearn()
   {
      int i,j,k;
      for(k=0;k<outputNodes;k++)
      {
         for(j=0;j<=hiddenNodes;j++)
         {
            w[j][k]+=BETA*error[k]*ew[j][k]; //update the second layer weights
            for(i=0;i<=inputNodes;i++)
               v[i][j]+=ALPHA*error[k]*ev[i][j][k]; //update the first layer weights
         }
      }
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******
    /* Updates the eligibility traces */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public final void UpdateElig()
  {
     int i,j,k;
     double temp[]=new double[outputNodes];
     double tm1=0;
     double tm2=0;
     for(k=0;k<outputNodes;k++)
        temp[k]=outputNode[k]*(1-outputNode[k]);
     for(j=0;j<=hiddenNodes;j++)
     {
        for(k=0;k<outputNodes;k++)
        {
           ew[j][k]=LAMBDA*ew[j][k]+temp[k]*hiddenNode[j];
           for (i=0;i<=inputNodes;i++)
           {
               ev[i][j][k]=LAMBDA*ev[i][j][k]+temp[k]*w[j][k]*hiddenNode[j]*(1-hiddenNode[j])*inputNode[i];
               tm1+=ev[i][j][k];
           }
          tm2+=ew[j][k];
        }
     }
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
      /* Main part of computation, where
         all of the above are combined */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public final void singleStep(double price, boolean setTo1)
  {
      int k;
      Response(); //forward pass - compute activities
      reward[0]=price;
      if(setTo1)
        outputNode[0]=1;
      for(k=0;k<outputNodes;k++)
      {
         error[k] = reward[k] + GAMMA*outputNode[k] - oldOutputNode[k]; //form errors
//         System.out.println("error[k] :"+error[k]);
      }
      TDlearn();          //backward pass - learning
      Response();     //forward pass must be done twice to form TD errors
      if(setTo1)
        outputNode[0]=1;
      for(k=0;k<outputNodes;k++)
         oldOutputNode[k] = outputNode[k];  //for use in next cycle's TD errors
      UpdateElig(); //update eligibility traces

  /*
// !!! me // ta tou Sutton, me /// ta tou panagioti !!!
     int k;
     Response(); // Just compute old response (old_y)...
     for(k=0;k<outputNodes;k++)
        oldOutputNode[k] = outputNode[k];
     UpdateElig();

    reward[0]=price;
    if(setTo1)
      outputNode[0]=1;
    Response();         // forward pass - compute activities
    for (k=0;k<outputNodes;k++)
      error[k] = reward[k] + GAMMA*outputNode[k] - oldOutputNode[k]; // form errors
    TDlearn();          // backward pass - learning
    Response();     // forward pass must be done twice to form TD errors
    if(setTo1)
      outputNode[0]=1;
    for(k=0;k<outputNodes;k++)
      oldOutputNode[k] = outputNode[k];  // for use in next cycle's TD errors
    UpdateElig();       // update eligibility traces
*/
 }

 // self-explanatory
 public final void setOldOutputNode(double timi){
    this.oldOutputNode[0]=timi;
 }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Transforms the pawns configuration to a binary array, that we use for input to the net.
   For each square we have 2 values, one for each player, the appropriate value is set to 1 or both to 0.
   We also measure how many pawns are still inside the base and we use 4 values for each player to
   state the percentage of the pawns that are still inside the base.
   Finally there are two more values, 1 for each, triggered in case someone has already won
*/
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
 public final void pawnsToInput(Pawn[] white, Pawn[] black)
 {
    int pos=0;
    int aspros=0;
    int mavros=0;

    this.inputNode=new double[inputNodes+1]; //array of input nodes //123
    this.inputNode[inputNodes]=BIAS;
    int shortcut=2*DIMBOARD*DIMBOARD-4*DIMBASE*DIMBASE;//112

    for(int i=0; i<NUMOFPAWNS;i++)
    {
       if((white[i].isAlive())&&(!white[i].isPawnInEnemyBase())&&(!white[i].isPawnInOwnBase()))
       {
          if(white[i].position.xCoord < DIMBASE)
             pos=white[i].position.xCoord*DIMBOARD +white[i].position.yCoord-(white[i].position.xCoord+1)*DIMBASE ;
          else
             if((white[i].position.xCoord >= DIMBASE)&&(white[i].position.xCoord < DIMBOARD-DIMBASE))
                pos=white[i].position.xCoord*DIMBOARD +white[i].position.yCoord - DIMBASE*DIMBASE ;
             else
                if(white[i].position.xCoord >= DIMBOARD-DIMBASE)
                   pos=white[i].position.xCoord*DIMBOARD +white[i].position.yCoord - (white[i].position.xCoord-DIMBOARD+2*DIMBASE)*DIMBASE ;
          this.inputNode[2*pos]=1;
       }

       if(white[i].isPawnInOwnBase())
          aspros++; // counts white pawns in base

       if(white[i].isPawnInEnemyBase())
          this.inputNode[shortcut+8]=1;  //white has already won

       if((black[i].isAlive())&&(!black[i].isPawnInEnemyBase())&&(!black[i].isPawnInOwnBase()))
       {
          if(black[i].position.xCoord < DIMBASE)
             pos=black[i].position.xCoord*DIMBOARD +black[i].position.yCoord - (black[i].position.xCoord+1)*DIMBASE ;
          else
             if((black[i].position.xCoord >= DIMBASE)&&(black[i].position.xCoord < DIMBOARD-DIMBASE))
                pos=black[i].position.xCoord*DIMBOARD +black[i].position.yCoord - DIMBASE*DIMBASE ;
             else
                if(black[i].position.xCoord >= DIMBOARD-DIMBASE)
                   pos=black[i].position.xCoord*DIMBOARD +black[i].position.yCoord - (black[i].position.xCoord-DIMBOARD+2*DIMBASE)*DIMBASE;
          this.inputNode[2*pos+1]=1;
       }

       if(black[i].isPawnInOwnBase())
          mavros++; //counts black pawns in base
       if(black[i].isPawnInEnemyBase())
          this.inputNode[shortcut+9]=1; // black has already won
    }
    //triggers the appropriate percentage
    if(aspros<=(int).25*NUMOFPAWNS)
       this.inputNode[shortcut]=1 ;
    else
       if(aspros<=(int)0.5*NUMOFPAWNS)
           this.inputNode[shortcut+1]=1;
       else
           if(aspros<=(int)0.75*NUMOFPAWNS)
             this.inputNode[shortcut+2]=1;
           else
             this.inputNode[shortcut+3]=1;

    if(mavros<=(int).25*NUMOFPAWNS)
       this.inputNode[shortcut+4]=1 ;
    else
       if(mavros<=(int)0.5*NUMOFPAWNS)
          this.inputNode[shortcut+5]=1;
       else
          if(mavros<=(int)0.75*NUMOFPAWNS)
             this.inputNode[shortcut+6]=1;
          else
             this.inputNode[shortcut+7]=1;
 }


// clears the arrays of the eligibility traces
 public final void clearEligTrace(){
    for (int j=0;j<=hiddenNodes;j++){
      for (int k=0;k<outputNodes;k++){
        ew[j][k]=0.0;
      }
      for (int i=0;i<=inputNodes;i++){
        for (int k=0;k<outputNodes;k++){
          ev[i][j][k]=0.0;
        }
      }
    }
 }
///
public final void saveInputNodesToFile()
{
      String str="";
      history inputNodesHistory=new history();
      TextArea inputNodesData=new TextArea();
      for(int k=0;k<inputNode.length;k++)
        str+=inputNode[k]+",";
      str+='\n';
      inputNodesData.append(""+str);
      inputNodesHistory.appendFile(inputNodesData.getText(),"INPUTNODES" );
}
}//this is the end