/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: The class of the pawn
*******/
import java.util.*;
import java.math.*;

public class Pawn implements Cloneable,Common{
  private int distance; // distance from base, used in order to determine if a move is legal
  private int id;       // pawn id
  private boolean white; // belongs to white??
  private boolean alive; //is alive??
  Square position;       // the square where this pawn resides
  private Square whiteBase=new Square(0,0,DIMBOARD,DIMBASE); // initiates the squares that make the white base
  private Square blackBase=new Square(DIMBOARD-1,DIMBOARD-1,DIMBOARD,DIMBASE); // initiates the squares that
                                                                               // make the black base
  public Pawn()
  {
    alive=true;
    position=whiteBase;
  }
  public Pawn(int noumero,boolean whiteColor)
  {
     id=noumero;
     white=(whiteColor==true)?true:false;
     position=(whiteColor==true)?whiteBase:blackBase;
     alive=true;
  }

  // move pawn from fromSquare to toSquare
  public final void movePawn(Square fromSquare,Square toSquare)
  {
//    System.out.println("inside movePawn");
    position=toSquare;
    fromSquare.setFree(); // set free the source square
    toSquare.setUnFree(); // and set unfree the sink square
  }

  // self-explanatory
  public final boolean isPawnInOwnBase(){
    return ((this.isAlive()==true)&&(((this.white)&&(this.position.isInWhiteBase()))||((!this.white)&&(this.position.isInBlackBase()))))?true:false;
  }

  // self-explanatory
  public final boolean isPawnInEnemyBase()
  {
    boolean res=false;
    if((this.isAlive())&&((this.white)&&(this.position.isInBlackBase())))
      res=true;

    if((this.isAlive())&&((!this.white)&&(this.position.isInWhiteBase())))
      res=true;
    return res;
//    return ((this.isAlive())&&(((this.white)&&(this.position.isInBlackBase()))||(!this.white)&&(this.position.isInWhiteBase())))?true:false;
  }

  // self-explanatory
  public final boolean isAlive(){
    return alive;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
           /* self-explanatory */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public final void killPawn()
  {
     position.setFree(); //release the square
     alive=false;
  }

//finds all possible moves a pawn can make, without checking legality
public final Square[] getAllMovesForWhitePawn(Square[][] outSquare)
{
  Square helpSquare[]=new Square[2*DIMBASE];
  for (int i=0;i<2*DIMBASE;i++)
      helpSquare[i]=new Square();
  if (this.isAlive())
  {
    if (this.isPawnInOwnBase())
    {
      for (int ii=0;ii<DIMBASE;ii++)
          helpSquare[ii]=outSquare[DIMBASE][ii];
      for  (int iii=DIMBASE;iii<2*DIMBASE;iii++)
          helpSquare[iii]=outSquare[iii-DIMBASE][DIMBASE];
    }
    else
    {
       if(position.xCoord==0)
       {
          helpSquare[0]=outSquare[1][position.yCoord];
          helpSquare[1]=outSquare[0][position.yCoord-1];
          if (position.yCoord<DIMBOARD-1)
             helpSquare[2]=outSquare[0][position.yCoord+1];
          }
      else
      {
          if (position.yCoord==0)
          {
            helpSquare[0]=outSquare[position.xCoord][1];
            helpSquare[1]=outSquare[position.xCoord-1][0];
            if (position.xCoord<DIMBOARD-1)
                   helpSquare[2]=outSquare[position.xCoord+1][0];
            }
            else
            {
               if (position.yCoord==DIMBOARD-1)
               {
                  helpSquare[0]=outSquare[position.xCoord+1][DIMBOARD-1];
                  helpSquare[1]=outSquare[position.xCoord][DIMBOARD-2];
                  helpSquare[2]=outSquare[position.xCoord-1][DIMBOARD-1];
               }
               else
               {
                  if(position.xCoord==DIMBOARD-1)
                  {
                    helpSquare[0]=outSquare[DIMBOARD-1][position.yCoord-1];
                    helpSquare[1]=outSquare[DIMBOARD-1][position.yCoord+1];
                    helpSquare[2]=outSquare[DIMBOARD-2][position.yCoord];
                  }
                  else
                  {
                      helpSquare[0]=outSquare[position.xCoord+1][position.yCoord];
                      helpSquare[1]=outSquare[position.xCoord-1][position.yCoord];
                      helpSquare[2]=outSquare[position.xCoord][position.yCoord+1];
                      helpSquare[3]=outSquare[position.xCoord][position.yCoord-1];
                  }
               }
            }
          }
      }

  }
  return helpSquare;
}

//finds all possible moves a pawn can make, without checking legality
  public final Square[] getAllMovesForBlackPawn(Square[][] outSquare){
   Square helpSquare[]=new Square[2*DIMBASE];
   for (int i=0;i<2*DIMBASE;i++){
      helpSquare[i]=new Square();
   }
   if (this.isAlive()){
    if (this.isPawnInOwnBase()){
      for (int i=0;i<DIMBASE;i++){
        helpSquare[i]=outSquare[DIMBOARD-1-DIMBASE][DIMBOARD-1-i];
      }
      for  (int i=DIMBASE;i<2*DIMBASE;i++){
        helpSquare[i]=outSquare[DIMBOARD+DIMBASE-1-i][DIMBOARD-1-DIMBASE];
      }
    }else if(position.xCoord==0){
            helpSquare[0]=outSquare[1][position.yCoord];
            helpSquare[1]=outSquare[0][position.yCoord-1];
            if (position.yCoord<DIMBOARD-1){
              helpSquare[2]=outSquare[0][position.yCoord+1];}
          }
          else if (position.yCoord==0){
            helpSquare[0]=outSquare[position.xCoord][1];
            helpSquare[1]=outSquare[position.xCoord-1][0];
            if (position.xCoord<DIMBOARD-1){
              helpSquare[2]=outSquare[position.xCoord+1][0];
            }
          } else
          if (position.yCoord==DIMBOARD-1){
            helpSquare[0]=outSquare[position.xCoord+1][DIMBOARD-1];
            helpSquare[1]=outSquare[position.xCoord][DIMBOARD-2];
            helpSquare[2]=outSquare[position.xCoord-1][DIMBOARD-1];
          } else if(position.xCoord==DIMBOARD-1){
            helpSquare[0]=outSquare[DIMBOARD-1][position.yCoord-1];
            helpSquare[1]=outSquare[DIMBOARD-1][position.yCoord+1];
            helpSquare[2]=outSquare[DIMBOARD-2][position.yCoord];
          } else

      {
      helpSquare[0]=outSquare[position.xCoord+1][position.yCoord];
      helpSquare[1]=outSquare[position.xCoord-1][position.yCoord];
      helpSquare[2]=outSquare[position.xCoord][position.yCoord+1];
      helpSquare[3]=outSquare[position.xCoord][position.yCoord-1];
    }
   }


    return helpSquare;
  }

// finds all legal moves for a pawn
public final Square[] getLegitMovesForWhitePawn(Square[][] outSquare)
{
  int i=0;int j=0;
  Square legSquare[]=new Square[2*DIMBASE];
  Square[] helpSquare=new Square[2*DIMBASE];
  for (int ii=0;ii<2*DIMBASE;ii++)
  {
    helpSquare[ii]=new Square();
    legSquare[ii]=new Square();
  }
  legSquare=this.getAllMovesForWhitePawn(outSquare);
  while ((i<2*DIMBASE)&&((legSquare[i].xCoord!=0)||(legSquare[i].yCoord!=0)))
  {
    int distanse=Math.max(position.xCoord+1-DIMBASE,position.yCoord+1-DIMBASE);
    int distanse2=Math.max(legSquare[i].xCoord+1-DIMBASE,legSquare[i].yCoord+1-DIMBASE);
    if (legSquare[i].isFree()&&(distanse2>=distanse ))
    {
       helpSquare[j++]=legSquare[i];
    }
    i++;
  }
  return helpSquare;
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    /* finds all legal moves for a pawn  */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
public final Square[] getLegitMovesForBlackPawn(Square[][] outSquare)
{
   int i=0;int j=0;
   Square[] legSquare=new Square[2*DIMBASE];
   Square[] helpSquare=new Square[2*DIMBASE];
   for (int ii=0;ii<2*DIMBASE;ii++)
   {
      helpSquare[ii]=new Square();
      legSquare[ii]=new Square();
   }
   legSquare=this.getAllMovesForBlackPawn(outSquare);
   while ((i<2*DIMBASE)&&((legSquare[i].xCoord!=0)||(legSquare[i].yCoord!=0)))
   {
      int distanse=Math.max(DIMBOARD-DIMBASE-position.xCoord,DIMBOARD-DIMBASE-position.yCoord);
      int distanse2=Math.max(DIMBOARD-DIMBASE-legSquare[i].xCoord,DIMBOARD-DIMBASE-legSquare[i].yCoord);
      if (legSquare[i].isFree()&&(distanse2>=distanse ))
      {
        helpSquare[j++]=legSquare[i];
      }
      i++;
   }
   return helpSquare;
}

/* --- */
//checking if a pawn can move, so that we can kill it
  public final boolean isWhitePawnMovable(Square[][] outSquare){
    Square[] helpSquare=new Square[2*DIMBASE];
    helpSquare=this.getLegitMovesForWhitePawn(outSquare);
    return ((helpSquare[0].xCoord==0)&&(helpSquare[0].yCoord==0))?false:true;
  }

//checking if a pawn can move, so that we can kill it
  public final boolean isBlackPawnMovable(Square[][] outSquare)
  {
////nikolini
    if ((this.isPawnInEnemyBase()))//&&(this.position.getXCoord()!=0)&&(this.position.getYCoord()!=0))
      return true;
////nikolini
    Square[] helpSquare=new Square[2*DIMBASE];
    helpSquare=this.getLegitMovesForBlackPawn(outSquare);
/*    System.out.println("-d-d-d-d-d-d-");
    for (int ij=0;ij<helpSquare.length;ij++)
        System.out.print(helpSquare[ij].getXCoord()+""+helpSquare[ij].getYCoord()+" ");
    System.out.println("");
*/    return ((helpSquare[0].xCoord==0)&&(helpSquare[0].yCoord==0))?false:true;
  }

//transform a pawn to a unique number
  public final int pawn2Tag(){
    if (this.isAlive()){
      return position.xCoord*DIMBOARD+position.yCoord+1;
    } else return DIMBOARD*DIMBOARD+1;
  }

//the inverse of the above procedure
  public final Pawn tag2Pawn(int tg){
    int tag=tg-1;
    Pawn tagPawn=new Pawn();
    tagPawn.position.xCoord=(int)tag/DIMBOARD;
    tagPawn.position.yCoord=(int) tag-DIMBOARD*(tagPawn.position.xCoord);
    return tagPawn;
  }

//so that we can clone pawns
  public final Object clone() {
    Object o = null;
    try {
      o = super.clone();
    } catch (CloneNotSupportedException e) {
        System.out.println("MyObject can't clone");
      }
    return o;
  }
}

