/***************
  Created by: Eirini Ntoutsi
  Operation:
*******/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class VisualBoardFrame extends JFrame implements Common
{
   public static JFrame myFrame;
   public static VisualBoard visualBoard;
   public static JTextField myText; //human input field
//   static public String inputFromTextField; //human input string
   public static SimpleWindow helpSimpleWindow;
   public static SimpleWindow historySimpleWindow;
   public static SimpleWindow infoSimpleWindow;
   public static JButton historyButton,plotButton,modelButton,closeButton,replayButton;

   static Player whitePlayer;
   static Player blackPlayer;
   static Player computerForWhitePlayer;

   //constructor: stin ousia aytos kanei oles is leitourgies
   public VisualBoardFrame(Player wPlayer,Player bPlayer,Player compForWPlayer)
   {
      super();
      myFrame=new JFrame();
      whitePlayer=wPlayer;
      blackPlayer=bPlayer;
      computerForWhitePlayer=compForWPlayer;
      JPanel mainPanel=new JPanel();
      JPanel toolbarPanel=new JPanel();
      visualBoard=new VisualBoard();
      JPanel boardPanel=new JPanel();

      Dimension boardDim = new Dimension(400,400);
      Dimension toolbarDim = new Dimension(100,32);
      Dimension buttonSize = new Dimension(30,30);

      mainPanel.setBackground(new Color(00,99,33));
      myFrame.getContentPane().setLayout(new BorderLayout());

      boardPanel.setPreferredSize(boardDim);
      boardPanel.setSize(boardDim);
      boardPanel.setMinimumSize(boardDim);
      boardPanel.setMaximumSize(boardDim);
      boardPanel.setPreferredSize(boardDim);
      boardPanel.add(visualBoard);

      toolbarPanel.setSize(toolbarDim);
      toolbarPanel.setPreferredSize(toolbarDim);
      toolbarPanel.setMinimumSize(toolbarDim);
      toolbarPanel.setMaximumSize(toolbarDim);

/* (1)to closeButton kai o listener tou */
      closeButton =new JButton(new ImageIcon("images/stop.gif"));
      closeButton.setToolTipText("Stop");
      closeButton.setSize(buttonSize);
      closeButton.setMinimumSize(buttonSize);
      closeButton.setMaximumSize(buttonSize);
      closeButton.setPreferredSize(buttonSize);
      class closeButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            System.exit(0);
         }
      }
    closeButtonActionListener myCloseAL=new closeButtonActionListener();
    closeButton.addActionListener(myCloseAL);
    toolbarPanel.add(closeButton);
/* ok me to closeButton*/

/* (1)to  modelButton kai o listener tou */
      modelButton =new JButton(new ImageIcon("images/model.gif"));
      modelButton.setToolTipText("Model");
      modelButton.setSize(buttonSize);
      modelButton.setMinimumSize(buttonSize);
      modelButton.setMaximumSize(buttonSize);
      modelButton.setPreferredSize(buttonSize);
      class modelButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            whitePlayer.modelOfPlayer.loadModel();
            String s1="Login:"+'\t'+whitePlayer.modelOfPlayer.getLogin()+'\n';
            if(whitePlayer.modelOfPlayer.getModel()==EXPERT)
               s1+="Model:"+'\t'+"EXPERT"+'\n';
            else
               if(whitePlayer.modelOfPlayer.getModel()==BEGINNER)
                  s1+="Model:"+'\t'+"BEGINNER"+'\n';
               else
                  if(whitePlayer.modelOfPlayer.getModel()==ADVANCED)
                     s1+="Model:"+'\t'+"ADVANCED"+'\n';
                  else
                     s1+="Model:"+'\t'+"UNKNOWN"+'\n';
            s1+="Number of win games:"+'\t'+whitePlayer.modelOfPlayer.getNumOfWinGames()+'\n';
            s1+="Number of lost games:"+'\t'+whitePlayer.modelOfPlayer.getNumOfLostGames()+'\n';
            String s2="Game"+'\t'+"Result"+'\t'+"Avg. values of moves"+'\t'+"Distance from best neural net suggestions"+'\t'+"Distance from worst neural net suggestions"+'\n';
            Vector tmp1=whitePlayer.modelOfPlayer.getHistoryOfGameResults();
            Vector tmp2=whitePlayer.modelOfPlayer.getHistoryOfAverageValuesPerMovePerGame();
            Vector tmp3=whitePlayer.modelOfPlayer.getMeanSquareDistanceFromNeuralNetBestSuggestions();
            Vector tmp4=whitePlayer.modelOfPlayer.getMeanSquareDistanceFromNeuralNetWorstSuggestions();

            for(int k=0;k<tmp1.size();k++)
            {
               s2+=""+(k+1)+'\t'+tmp1.get(k)+'\t'+tmp2.get(k)+'\t'
               +tmp3.get(k)+"  "+'\t'+'\t'+tmp4.get(k)+'\n';
            }
            s2+="\n\nEXPLANATION\nResult:  1 for the winner, 0 for the loser\n\n"+
                "Avg. values of moves:  the average value of your moves for the corresponding game\n\n"+
                "Distance from best neural net suggestions:  the mean square distance between your moves and neural net best suggested moves. "+
                "It is computed by the expression: �[(x-y)*(x-y)], where x is the value of the neural net best suggestion and y is the value of your move for all moves of the corresponding game.\n\n"+
                "Distance from worst neural net suggestions:  the mean square distance between your moves and neural net worst suggested moves. "+
                "It is computed by the expression: �[(z-w)*(z-w)], where z is the value of your move and w is the value of the neural net worst suggestion for all moves of the corresponding game.\n\n";
            infoWindow myInfoWindow = new infoWindow("Model information",s1,"Game details",s2);
            myInfoWindow.showInfoWindow();
         }
      }
      modelButtonActionListener myModelAL=new modelButtonActionListener();
      modelButton.addActionListener(myModelAL);
      toolbarPanel.add(modelButton);
/* ok me to modelButton*/

/* (2)to  historyButton kai o listener tou */
      historyButton =new JButton(new ImageIcon("images/history.gif"));
      historyButton.setToolTipText("History");
      historyButton.setSize(buttonSize);
      historyButton.setMinimumSize(buttonSize);
      historyButton.setMaximumSize(buttonSize);
      historyButton.setPreferredSize(buttonSize);
      class historyButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            String sHelp="#\tYour moves\t\t\t    <----> \t\tComputer moves\n";
            String wHistory=whitePlayer.toWSaveGame.getText();
            String bHistory=blackPlayer.toBSaveGame.getText();
            StringTokenizer stW = new StringTokenizer(wHistory.replace('\n',' '));
            StringTokenizer stB = new StringTokenizer(bHistory.replace('\n',' '));
            String whiteRemainPawns="\nActive pawns for white "+Spiel.myPosition.getWhiteRemaining(Spiel.myPosition.whitePawns);
            String blackRemainPawns=" \tActive pawns for black "+Spiel.myPosition.getBlackRemaining(Spiel.myPosition.blackPawns);
            String gameMoves="";
            int k=0;
            while (stB.hasMoreTokens())
            {
               gameMoves+=(k+1)+")\t"+stW.nextToken()+"\t\t\t"+stB.nextToken()+"\n";
               k++;
            }
            // o aspros mporei na exei mia akomi kinisi => check it
            if (stW.hasMoreTokens())
            {
               gameMoves+=(k+1)+")\t"+stW.nextToken()+'\n';
            }
            sHelp+=gameMoves;
            sHelp+=whiteRemainPawns;
            sHelp+=blackRemainPawns;
            Dimension historySize=new Dimension(600,400);
            historySimpleWindow = new SimpleWindow("Game moves for both players",sHelp+'\n',historySize);
            historySimpleWindow.showSimpleWindow();
         }
      }
          historyButtonActionListener myHistoryAL=new historyButtonActionListener();
          historyButton.addActionListener(myHistoryAL);
          toolbarPanel.add(historyButton);
      /* ok me to historyButton*/

/* (3)to plotButton kai o listener tou */
      plotButton =new JButton(new ImageIcon("images/plot.gif"));
      plotButton.setToolTipText("Graph");
      plotButton.setSize(buttonSize);
      plotButton.setMinimumSize(buttonSize);
      plotButton.setMaximumSize(buttonSize);
      plotButton.setPreferredSize(buttonSize);
      class plotButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            //oi kalyteres kiniseis pou tou proteinei o ypologistis
            Vector v1=computerForWhitePlayer.modelOfPlayer.getNeuralNetBestSuggestion();
            //oi dikes tou kiniseis
            Vector v2=whitePlayer.modelOfPlayer.getValueOfChoosenMoves();
            //oi xeiroteres kiniseis pou tou proteinei o ypologistis
            Vector v3=computerForWhitePlayer.modelOfPlayer.getNeuralNetWorstSuggestion();
            PlotXY myGraph = new PlotXY(v1,v2,v3);
            myGraph.showPlotXY();
         }
      }
      plotButtonActionListener myPlotAL=new plotButtonActionListener();
      plotButton.addActionListener(myPlotAL);
      toolbarPanel.add(plotButton);
/* ok me to plotButton*/

/* (4)to helpButton kai o listener tou */
      JButton helpButton =new JButton(new ImageIcon("images/help.gif"));
      helpButton.setToolTipText("Help");
      helpButton.setSize(buttonSize);
      helpButton.setMinimumSize(buttonSize);
      helpButton.setMaximumSize(buttonSize);
      helpButton.setPreferredSize(buttonSize);
      class helpButtonActionListener implements ActionListener
      {
       public void actionPerformed(ActionEvent evt)
       {
          String sHelp="\t\t\t  Possible moves:\nMove\t\tFrom square\t\tTo square\t\tValue of movement\n"+whitePlayer.nextMoveSuggestionsForHuman;
          sHelp+="\nRemaining active pawns for you: "+Spiel.myPosition.getWhiteRemaining(Spiel.myPosition.whitePawns);
          Dimension helpSize=new Dimension(600,400);
          helpSimpleWindow = new SimpleWindow("Get a hint for your next move",sHelp,helpSize);
          helpSimpleWindow.showSimpleWindow();
       }
    }
    helpButtonActionListener myHelpAL=new helpButtonActionListener();
    helpButton.addActionListener(myHelpAL);
    toolbarPanel.add(helpButton);
/* ok me to helpButton*/

/* (5)to infoButton kai o listener tou */
      JButton infoButton =new JButton(new ImageIcon("images/info.gif"));
      infoButton.setToolTipText("Info");
      infoButton.setSize(buttonSize);
      infoButton.setMinimumSize(buttonSize);
      infoButton.setMaximumSize(buttonSize);
      infoButton.setPreferredSize(buttonSize);
      class infoButtonActionListener implements ActionListener
      {
       public void actionPerformed(ActionEvent evt)
       {
          String sInfo="\t\t\t  The game:\n";
          sInfo+="The game is played on a rectangular board of of dimension nxn.At the lower left and upper right part of the board are located the players' bases, each of dimension axa. Each player posssess � pawns, tha initially are inside the corresponding base, which is considered as one square and not as a set of squares.\n";
          sInfo+="\t\t\t  The goal:\n";
          sInfo+="Each player's goal is to get one of his pawns into the enemy base. If a player runs out of pawns, the opponent is declared as winner.\n";
          sInfo+="\t\t\t  The rules:\n";
          sInfo+="Each pawn can move to an empty square that is vertically or horizontaly adjacent, provided that the pawn's maximum distance from its base is not decreased. Backward moves are not allowed. As soon as a move has taken place, all pawns that have no legal move are pronounced 'inactive' and are removed.";
          Dimension infoSize=new Dimension(600,400);
          infoSimpleWindow = new SimpleWindow("About the game",sInfo,infoSize);
          infoSimpleWindow.showSimpleWindow();
       }
      }
      infoButtonActionListener myInfoAL=new infoButtonActionListener();
      infoButton.addActionListener(myInfoAL);
      toolbarPanel.add(infoButton);
/* ok me to infoButton*/

/* --- End of listeners --- */

    mainPanel.add(BorderLayout.CENTER,boardPanel);
    mainPanel.add(BorderLayout.SOUTH,toolbarPanel);

    myFrame.getContentPane().add(BorderLayout.NORTH,boardPanel);
    myFrame.getContentPane().add(BorderLayout.SOUTH,toolbarPanel);
    myFrame.setSize(500,460);
    myFrame.setResizable(false);
    myFrame.setVisible(true);
    myFrame.repaint();
    myFrame.addWindowListener(
    new WindowAdapter()
    {
        public void windowClosing(WindowEvent e)
        {
	   System.exit(0);
        }
    });
}

    public static void clearVisualBoard()
    {
       visualBoard.clearVisualBoardPawns();
    }

    public static void setButtonsEnable(boolean enable,int k)
    {
        historyButton.setEnabled(enable);
        if((enable==true)&&(k>1))
          plotButton.setEnabled(true);
        else
          plotButton.setEnabled(false);
    }
//this is the end
}
